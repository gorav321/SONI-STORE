// JavaScript to handle product interactions
document.addEventListener("DOMContentLoaded", function () {

    // Get all product cards
    const products = document.querySelectorAll('.product');

    // Add event listeners to each product
    products.forEach(product => {
        product.addEventListener('click', function () {
            const productName = this.querySelector('h3').textContent;
            const productPrice = this.querySelector('.price').textContent;

            // Display a message with product name and price
            alert(`You selected: ${productName}\nPrice: ${productPrice}`);
        });
    });

});
<script src="script.js"></script>
</body>